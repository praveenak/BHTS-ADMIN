//Creates new instance of the class 'AJAXRequest' using specific configuration.
//The configuration is supplied as an object.
window.ajax = new AJAXRequest({

    //Show more messages in the console. Activate in development mode only.
    verbose:true,

    // The end pont at which that will receive the request.
    url: SERVER_URL + ":" + SERVER_PORT + API_END_POINT + "/" + ADMIN_LOGIN,

    //The method which is used to call the end point.
    method:'get',

    //Adding one callback which will get executed before AJAX
    //Request is sent. The callback in this case is
    //Used to collect user input and validate it.
    //If it is invalid, intercept the request and disable AJAX.
    //If valid, add it as request parameter and continue.
    //Notice how we accessed the methods of the instance using 'this.AJAXRequest'.
    beforeAjax: function () {
        var login_status = document.getElementById('load-icon');
        window.myList = login_status;
        var username = document.getElementById('username').value.trim();
        var password = document.getElementById('password').value.trim();
        //if (username.length === 0 || password.length === 0) {
        //    this.AJAXRequest.setEnabled(false);
        //    login_status.innerHTML = '<li>Please enter vendor name.</li>';
        //    return;
        //} else {
            this.AJAXRequest.setEnabled(true);
        //}

        login_status.innerHTML = '<small id="loader" class="d-flex align-items-center justify-content-center"><img src="images/custom/loader.gif" alt="loading..."></small>';

        this.AJAXRequest.setParams({
            username:username,
            password:password,
            role:2
        });
    },

    //Add one callback which will get executed after ajax
    //request completed with success status (2xx or 3xx).
    onSuccess: function () {
        alert('Fetched.');
        var response = this.jsonResponse.packageNames;

        var statusBody = '';
        for (var x = 0 ; x < response.length ; x++) {
            var token = packages[x];
            statusBody = token;
        }
        if (statusBody.length === 0) {
            statusBody = '<li>No response found.';
        }
        window.myList.innerHTML = statusBody;
    },

    //Adding two callbacks which will get executed after ajax
    //request completed with client error status (4xx).
    //What we do is simply display the response code of the server.
    onClientErr:[
        function () {
            window.myList.innerHTML = '<li>'+this.status+'</li>';
        },
        function () {
            alert('Error: '+this.status);
        }
    ],

    //One callback which will get executed after ajax
    //request completed with server error status (5xx).
    //What we do is simply display the response code of the server.
    onServerErr: function () {
        window.myList.innerHTML = '<li>'+this.status+'</li>';
    },

    //An array that contains two callbacks which will get executed if no
    //internet connection is available
    onDisconnected: [
        function () {
            window.myList.innerHTML = '<li>No internet access.</li>';
        },
        function () {
            alert('Make sure that you are connected to the internet. (code '+this.status+')');
        }
    ]
});
