
function validate_login() {
    $("#loginForm").click(function(event) {

      // make selected form variable
      var vForm = $("#loginForm");

      /*
      If not valid prevent form submit
      https://developer.mozilla.org/en-US/docs/Web/API/HTMLSelectElement/checkValidity
      */
      if (vForm[0].checkValidity() === false) {
        event.preventDefault();
        event.stopPropagation();
      } else {
        event.preventDefault();
        //$('#load-icon').html('<small id="loader" class="d-flex align-items-center justify-content-center"><img src="images/custom/loader.gif" alt="loading..."></small>');
        window.ajax.send();
      }

      // Add bootstrap 4 was-validated classes to trigger validation messages
      vForm.addClass('was-validated');
    });
};

function validate_fpassword() {
  var username = $('#username')[0].value;
  if(username == '') {
    event.preventDefault();
    //$('#username').addClass('red-border');
    $('#username').css("border","0.3px solid red");
  } else {
    //$('#username').addClass('green-border');
    //$('#username').focus();
    $('#username').css("border","0.3px solid green");
  }
}

function validate_change_pwd() {
  var pwd = $('#myPassword')[0].value;
  var pwdConfirm = $('#myPasswordConfirm')[0].value;

  if(pwd !== pwdConfirm) {
    event.preventDefault();
    //$('#username').addClass('red-border');
    $('#myPasswordConfirm').css("border","0.3px solid red");
  }
}
