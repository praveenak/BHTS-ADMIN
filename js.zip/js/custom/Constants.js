class TokenHandler {
  static token = "";
  constructor() {
    if (this instanceof TokenHandler) {
      throw Error('TokenHandler class is static and cannot be instantiated.');
    }
  }
}

const SERVER_URL = "http://127.0.0.1";
const SERVER_PORT = "8000";
const APP_NAME = "Bariatric Healthcare Tracking System";
const API_END_POINT = "/api";
const ADMIN_LOGIN = "admin/login";
const SUPER_ADMIN_LOGIN = "sadmin/login";
